
#include "device.h"



CVADTreat::CVADTreat()
{
	m_bStop = false;
	m_runing = false;
	m_szDescription = "����ʶ���߳�";
	//open();
}

CVADTreat::~CVADTreat(void)
{
	m_bStop = true;

	for (int t = 0; t < 500; t++)
	{
		if (m_runing)
			mysleep(10);
		else
			break;
	}
	stop();
}

//�²���ã�����Ϣ����
int CVADTreat::svc()
{
	m_runing = true;

	// whisper init
	string path = getExePath();
	struct whisper_context* ctx_wsp = whisper_init_from_file((path + "voicemodel/ggml-base.bin").c_str());
	// init audio

	audio_async audio(30 * 1000);
	if (!audio.init(-1, WHISPER_SAMPLE_RATE)) {
		fprintf(stderr, "%s: audio.init() failed!\n", __func__);
		return 1;
	}

	audio.resume();

	whisper_full_params wparams = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
	wparams.print_progress = false;
	wparams.print_special = false;
	wparams.print_realtime = false;
	wparams.print_timestamps = false;
	wparams.translate = false;
	wparams.no_context = true;
	wparams.single_segment = true;
	wparams.max_tokens = 32;
	wparams.language = "zh";
	wparams.n_threads = std::min(4, (int32_t)std::thread::hardware_concurrency());
	wparams.audio_ctx = 0;
	wparams.speed_up = false;

	float vad_thold = 0.6f;
	float freq_thold = 100.0f;
//	int32_t voice_ms = 10000;

	std::vector<float> pcmf32_cur;

	sendHeartBeat();
	while (!m_bStop)
	{
		audio.get(2000, pcmf32_cur);
		if (::vad_simple(pcmf32_cur, WHISPER_SAMPLE_RATE, 1250, vad_thold, freq_thold, false))
		{
			//	fprintf(stdout, "%s: Speech detected! Processing ...\n", __func__);
			//	audio.get(voice_ms, pcmf32_cur);

			std::string text_heard = "";
			if (whisper_full(ctx_wsp, wparams, pcmf32_cur.data(), pcmf32_cur.size()) != 0)
				continue;
			else
			{
				const int n_segments = whisper_full_n_segments(ctx_wsp);
				for (int i = 0; i < n_segments; ++i)
				{
					const char* text = whisper_full_get_segment_text(ctx_wsp, i);
					text_heard += text;
				}
				text_heard = ::trim(text_heard);
			}
			if (treat(text_heard))
			{
				//	fprintf(stdout, "%s: Heard nothing, skipping ...\n", __func__);
				audio.clear();
				continue;
			}
			audio.clear();
		}
		else
		{
			// delay
			std::this_thread::sleep_for(std::chrono::milliseconds(100));
		}
	}

	audio.pause();

	whisper_print_timings(ctx_wsp);
	whisper_free(ctx_wsp);

	m_runing = false;
	return 0;
}

bool CVADTreat::treat(string& text_heard)
{
	text_heard = CHASCII(text_heard);
	// remove text between brackets using regex
	{
		std::regex re("\\[.*?\\]");
		text_heard = std::regex_replace(text_heard, re, "");
	}

	// remove all characters, except for letters, numbers, punctuation and ':', '\'', '-', ' '
//	text_heard = std::regex_replace(text_heard, std::regex("[^a-zA-Z0-9\\.,\\?!\\s\\:\\'\\-]"), "");

	// take first line
	text_heard = text_heard.substr(0, text_heard.find_first_of('\n'));

	// remove leading and trailing whitespace
	text_heard = std::regex_replace(text_heard, std::regex("^\\s+"), "");
	text_heard = std::regex_replace(text_heard, std::regex("\\s+$"), "");

	if (text_heard.empty() ) 
		return false;
	
	return true;
}


CDevice::CDevice()
{
	m_procAddress = "";
	m_cfgAdd = "";
	pSpVoice = NULL;
	m_iState = -1;
	m_mb = NULL;
	m_timeout = 10000;//10�볬ʱ
	m_time_start = clock();
	m_szMyName = "СС";
}
CDevice::~CDevice()
{
	if (pSpVoice != NULL)
	{
		((ISpVoice*)pSpVoice)->Speak(L"�˳���������", SPF_PURGEBEFORESPEAK | SPF_DEFAULT, NULL);
		((ISpVoice*)pSpVoice)->Release();
		pSpVoice = NULL;
	}
}
void CDevice::loadcfg()
{
	if ("" != m_cfgAdd)
	{
		CConfig cfg(m_cfgAdd);
		string szVal = cfg.getItem("procAddress");
		if ("" != szVal)
		{
			m_procAddress = szVal;
		}
		if ("" != m_procAddress)//Ŀ¼���Զ��ҵ������궨λ�������ļ���ģ��ͼƬ ���ܼ��سɹ� 
		{
		}
	}
	if (pSpVoice == NULL)
	{
		if (FAILED(CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void**)&pSpVoice)))
		{
			AfxMessageBox("���ܳ�ʼ������");
		}
		else {
			Speech("��������ģ����سɹ�");
		}
	}
}
void CDevice::writecfg()
{
	if ("" != m_cfgAdd)
	{
		remove(m_cfgAdd.c_str());
		CConfig cfg(m_cfgAdd);
		cfg.updateItem("\n#�Ƴ̵�ַ", "");
		cfg.updateItem("reportAddress", m_procAddress);
	}
}

void CDevice::Speech(CString str, bool clear) 
{
	if (pSpVoice != NULL) {
		if (clear) {
			((ISpVoice*)pSpVoice)->Speak(str.AllocSysString(), SPF_ASYNC | SPF_PURGEBEFORESPEAK, NULL);
		}
		else {
			((ISpVoice*)pSpVoice)->Speak(str.AllocSysString(), SPF_ASYNC | SPF_DEFAULT, NULL);     // �ʶ����ĺ�Ӣ�ĵĻ���ַ���   
		}
	}
}

bool CDevice::treat(string& text_heard)
{
	if (!CVADTreat::treat(text_heard))
		return false;
	if (-1 == m_iState )
	{
		if (-1 != text_heard.find(m_szMyName))
		{
			m_iState = 0;
			m_time_start = clock();
			Speech("�յ� ��ָʾ");
		}
		if (m_mb->m_iPause)
			Speech("�豸��ͣ");
		return true;
	}
	else if (m_timeout < m_time_start - clock())
	{
		m_iState = -1;
		if (m_mb->m_iPause)
			Speech("�豸��ͣ");
		return true;
	}
	/*if (-1 != text_heard.find("��ͣ"))
	{
		Speech(("�յ�" + text_heard).c_str());
		if (!m_mb->m_iPause)
			m_mb->pauseAll();
		else
			Speech("����ͣ");
	}
	else if (-1 != text_heard.find("����"))
	{
		Speech(("�յ�" + text_heard).c_str());
		if (m_mb->m_iPause)
			m_mb->pauseAll();	
		else
			Speech("������");
	}
	else */if (-1 != text_heard.find("����")|| -1 != text_heard.find("��")|| -1 != text_heard.find("����") || -1 != text_heard.find("����"))
	{
		Speech(("�յ�" + text_heard).c_str());
		if (m_mb->m_iState != -1)//��ͣ״̬
		{
			Speech("��ͣ״̬��");
			return true;
		}
		m_mb->m_io.ioTrigPause(false);
		string command = m_mb->m_szChainMv;//getListInfo();
		if (command != "")
		{
			m_mb->updateProb();
			m_mb->pushMsg(command);
			//g_MB->svcPause(false);
		}
	}
	else if (-1 != text_heard.find("ͣ"))
	{
		Speech(("�յ�" + text_heard).c_str());
		m_mb->Mvstop();
	}
	else
	{
		std::map<string, string>::iterator it = m_mpComd.find(text_heard);
		if (it != m_mpComd.end())
		{
			Speech(("�յ�" + text_heard).c_str());
			if (NULL != m_mb)
			{
				string str = it->second + CHAINFLAG;
				m_mb->pushMsg(str);
			}
		}
	}
	return true;
}
